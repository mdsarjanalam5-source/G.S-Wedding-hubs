G.S WEDDING HUB — ANDROID APK PROJECT

यह ZIP Android source project है; यह खुद install होने वाली APK नहीं है।

MOBILE PAR APK DIRECT DOWNLOAD KARNE KA TARIKA:
1. इस ZIP को अपने GitHub repository में source files/folders के रूप में upload करें।
2. GitHub repository में Settings > Actions > General खोलें और workflow को repository पर चलने दें। Release बनाने के लिए workflow token को contents write permission चाहिए; workflow में यह permission सेट है।
3. Actions tab > “Build G.S Wedding Hub APK” > Run workflow दबाएँ।
4. Build सफल होने के बाद Releases में “G.S Wedding Hub APK build …” खोलें और app-debug.apk डाउनलोड करें। Release asset एक सीधी .apk फाइल है, इसे ZIP की तरह extract नहीं करना पड़ेगा।
5. Android पर APK खोलकर install करें। यदि फोन अनुमति माँगे तो उस स्रोत से app install करने की अनुमति दें।

ALTERNATIVE:
Actions run > Artifacts > GS-Wedding-Hub-APK डाउनलोड करने पर GitHub artifact ZIP मिलता है; उस ZIP को extract करना पड़ेगा। सीधे APK के लिए Releases वाला तरीका इस्तेमाल करें।

FEATURES INCLUDED IN CURRENT HTML APP:
- G.S Wedding Hub branding
- Photo/video gallery upload (local device storage limitations apply)
- Reviews and ratings (local device only)
- WhatsApp/call links: +91 7321805421 and +91 9279591849
- Quotation request via WhatsApp
- Demo admin panel and local data export

DEMO ADMIN PASSWORD: GSAdmin@7321

IMPORTANT LIMITATIONS:
- Admin password is hard-coded/client-side demo authentication; do not use it as secure public authentication.
- Gallery and reviews are stored locally on the device/WebView, not synced between customers.
- Shared admin controls, cross-device media/reviews, online bookings, notifications and secure user accounts require a backend/database and proper authentication.
- This is a debug APK workflow. For public distribution, configure a signing key and build a signed release APK.
- The APK is not included in this source ZIP; GitHub Actions must build it.
